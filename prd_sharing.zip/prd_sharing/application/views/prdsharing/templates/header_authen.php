<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!-- IE Compatibility modes -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PRDSHARING</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../favicon.ico">
    
	<script src="<?php echo base_url(); ?>js/jqueryui/jquery-1.10.2.js"></script>
	<link rel="stylesheet" href="<?php echo base_url(); ?>css/jqueryui/jquery-ui-1.10.4.custom.min.css">
	<script src="<?php echo base_url(); ?>js/jqueryui/jquery-ui-1.10.4.custom.min.js"></script> 
	
	<!-- <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.12.0/jquery.validate.min.js"></script> -->
	<!-- <script src="http://jquery.bassistance.de/validate/jquery.validate.js"></script>
	<script src="http://jquery.bassistance.de/validate/additional-methods.js"></script> -->

    <link href="<?php echo base_url(); ?>css/reset.css" rel="stylesheet" charset="utf-8">
    <link href="<?php echo base_url(); ?>css/style.css" rel="stylesheet" charset="utf-8">
    <script src="<?php echo base_url(); ?>js/ckeditor.js"></script>
<?php
    if($title == "Sent News"){
 	   ?><link rel="stylesheet" href="<?php echo base_url(); ?>css/sample.css"><?php
	}
?>
</head>
<body>
    <div class="container">
    <!-- HEADER -->
        <div class="wrapper">
            <div class="bg-header">
                <div id="header">
                   <div class="logo">
                        <img src="<?php echo base_url(); ?>images/prdsharing_Login.png" alt="Logo" style="width:auto;">
                    </div>
                </div>
            </div>
        </div>
    <!-- Content -->
        <div class="wrapper">